package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
Button btn;
EditText editText;
TextView weathertype,country,city,tempature,humidity,due,fellslike;
ImageView imageView;




//https://api.openweathermap.org/data/2.5/weather?q=mysuru&appid=37bc0d54466ae717c378ede71314805a
String baseURL="https://api.openweathermap.org/data/2.5/weather?q=";
String API="&appid=37bc0d54466ae717c378ede71314805a";
    private RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weathertype=findViewById(R.id.Weather_type);
        country=findViewById(R.id.country);
        city=findViewById(R.id.city);
        tempature=findViewById(R.id.temperature);
        humidity=findViewById(R.id.Humadity);
        due=findViewById(R.id.Due);
        fellslike=findViewById(R.id.FeelLike);
        editText=findViewById(R.id.editText);
        btn=findViewById(R.id.button);
        imageView=findViewById(R.id.Forcast);

        requestQueue = MySingleton.getInstance(this).getRequestQueue();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String myURL=baseURL + editText.getText().toString() + API;
              // Log.i("url","url " +myURL);


                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, myURL, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("weather");
                            JSONObject main=response.getJSONObject("main");
                            JSONObject contoryobj=response.getJSONObject("sys");
                            String temp=main.getString("temp");
                            String humid=main.getString("humidity");
                            String  presure=main.getString("pressure");
                            String maxtempature=main.getString("temp_max");
                            String myConturyname=contoryobj.getString("country");
                            //JSONObject cityname=response.getJSONObject("name");
                            //String thecityname=cityname.getString("name");
                            String cityname=response.getString("name");
                            city.setText(cityname);
                            tempature.setText(temp);
                            humidity.setText(humid);
                            due.setText(presure);
                            fellslike.setText(maxtempature);
                            country.setText(myConturyname);
                            for (int i=0; i < jsonArray.length(); i++){
                                JSONObject parobj = jsonArray.getJSONObject(i);
                                String myweather=parobj.getString("main");
                                String icon=parobj.getString("icon");
                                weathertype.setText(myweather);
                                switch (icon)
                                {
                                    case "11d":
                                        imageView.setImageResource(R.drawable.storm);
                                        break;
                                    case "09d":
                                        imageView.setImageResource(R.drawable.rainy_day);
                                        break;
                                    case "10d":
                                        imageView.setImageResource(R.drawable.rainy_day);
                                        break;
                                    case "13d":
                                        imageView.setImageResource(R.drawable.frezzrain);
                                        break;
                                    case " 13d":
                                        imageView.setImageResource(R.drawable.frezzrain);
                                        break;
                                    case "50d":
                                        imageView.setImageResource(R.drawable.haze);
                                        break;
                                    case "01d":
                                        imageView.setImageResource(R.drawable.sun);
                                        break;
                                    case "01n":
                                        imageView.setImageResource(R.drawable.sun);
                                        break;
                                    case "02d":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;
                                    case "02n":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;
                                    case "03d":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;
                                    case "03n":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;
                                    case"04d":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;
                                    case "04n":
                                        imageView.setImageResource(R.drawable.cloud);
                                        break;


                                }




                            }






                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this,
                                "SomeThing Went Wrong", Toast.LENGTH_LONG).show();
                    }
                });

                requestQueue.add(request);





            }








        });




}
}

